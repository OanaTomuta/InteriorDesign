import React, {useEffect, useState} from "react";
import CardItem from './CardItem';
import './Cards.css';
import {Button} from "../button/Button";
import {fetchRooms} from "../../utils/apiClient";
import {I18Provider} from "../i18n";
import translate from "../i18n/translate";

function SelectRoomCards({onChange,locale}) {


    const [rooms, setRooms] = useState([]);

    const refresh = async () => {

        console.log("called");
        const result = await fetchRooms();
        const data = result.map( r => ({
            room_id : r.room_id,
            name : r.name,
            image_id: r.image_id
        }));

        setRooms(data);
    }

    useEffect( () =>{
        refresh().catch(err => console.log(err));
    },[]);

    const [selectedRooms, setSelectedRooms] = useState([]);

    const onClick = (room) => {
        let newRooms = [];
        if (selectedRooms.includes(room)) {
            let index = selectedRooms.indexOf(room);
            newRooms = [...selectedRooms];
            if (index > -1) {
                newRooms.splice(index, 1);
            }
        } else {
            newRooms = [...selectedRooms, room]; //creeaza un nou array cu elem din rooms, spread operator
        }
        setSelectedRooms(newRooms);
        onChange(newRooms); //functia in care se modifica setCards din AppointmentRooms
    };

    console.log(selectedRooms);

    return (
        <I18Provider locale={locale}>
            <div className={"cards"}>
                <h1>{translate('select-room-header')}</h1>
                <div className={"cards-container"}>
                    <div className={"cards-wrapper"}>
                        <ul className={"cards-items"}>
                            {
                                rooms.map( roomCard => (
                                    <CardItem
                                        src={`/load-image?img_id=${roomCard.image_id}`}
                                        text={roomCard.name}
                                        id={roomCard.room_id}
                                        onClick={onClick}
                                    />
                                ))
                            }
                        </ul>
                    </div>
                </div>

            </div>
        </I18Provider>
    )

}

export default SelectRoomCards;