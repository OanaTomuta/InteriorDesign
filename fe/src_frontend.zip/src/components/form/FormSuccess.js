import React from "react";
import './Form.css'

const FormSuccess = () => {

    return(
        <div className={"form-content"}>
            <div className={"form-success"}>
                We have received your request!
            </div>
        </div>
    )
}

export default FormSuccess;