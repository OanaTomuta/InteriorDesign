export const LANGUAGES = {
    ENGLISH: 'en',
    ROMANIAN: 'ro',
}

