import en from "./en";
import ro from "./ro";

export default {
    ...en,
    ...ro
}