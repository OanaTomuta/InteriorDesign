import React from "react";
import { Icon } from './styles/icons';

export default function Icons({className}){
    return <Icon className={className}/>
}