import styled from 'styled-components';

export const Icon = styled.i`
    font-size: 12px;
    margin-right: 5px;
    background: #323e1a;
`